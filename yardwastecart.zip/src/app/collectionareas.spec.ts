import { Collectionareas } from './collectionareas';

describe('Collectionareas', () => {
  it('should create an instance', () => {
    expect(new Collectionareas()).toBeTruthy();
  });
});
