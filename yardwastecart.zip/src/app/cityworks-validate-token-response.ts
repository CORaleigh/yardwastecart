export interface CityworksValidateTokenResponse {
  Value: boolean;
  Status: number;
  Message?: any;
  ErrorMessages: any[];
  WarningMessages: any[];
  SuccessMessages: any[];
}
