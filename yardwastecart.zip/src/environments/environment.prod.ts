export const environment = {
  production: true,
  user: `cwsoa`,
  password: `cwsoa1`
  // user: `coraleigh/seeclickfix`,
  // password: `ts%dWLc%XaSB`
};
